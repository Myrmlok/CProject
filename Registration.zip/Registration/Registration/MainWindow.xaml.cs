﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Net;
using System.Net.Sockets;
using System.Text.Json;
using Registration;
namespace Registration
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    
    public partial class MainWindow : Window
    {
        static TcpClient client;
        public MainWindow()
        {
            InitializeComponent();
            client = new TcpClient();

        }
        
        private void Button_Click_Register(object sender, RoutedEventArgs e)
        {
            if (RPassword.Text.Trim() == "" || RLogin.Text.Trim() == "")
            {
                MessageBox.Show("Поля обязательны для заполнения");
                return;
            }
            if (RPassword.Text != RRepeatPassword.Text)
            {
                MessageBox.Show("Пароли не совпадают ");
                return;
            }
            client.Connect(Dns.GetHostEntry(Dns.GetHostName()).AddressList[0], 8888);
            IsConnected();
            ParseFromClient parseFromClient = new ParseFromClient()
            {
                Requset = "AddUser",
               
                Name = RLogin.Text,
                Password = RPassword.Text,
                
                IsContains = false
               
            };
            WriteStream(parseFromClient);
            var Parse = JsonSerializer.Deserialize<ParseFromClient>(StreamRead(client.GetStream()));
            if (!Parse.IsContains)
            {
                Register.Visibility = Visibility.Hidden;
            }
        }
        static void WriteStream(ParseFromClient parseFromClient)
        {
            using (NetworkStream stream = client.GetStream())
            {
                byte[] data = Encoding.UTF8.GetBytes(JsonSerializer.Serialize<ParseFromClient>(parseFromClient));
                stream.Write(data, 0, data.Length);
            }
        }
        public void IsConnected()
        {
            if (client.Connected == false)
            {
                MessageBox.Show("Не удалось подключиться к серверу");
                Close();
            }
        }
        static string StreamRead(NetworkStream stream)
        {
            string FinalResult = "";
            while (true)
            {

                byte[] recieve = new byte[1024];
                var byteCount = stream.Read(recieve, 0, recieve.Length);
                if (byteCount < 1024)
                {
                    FinalResult += Encoding.UTF8.GetString(recieve, 0, byteCount);

                    break;
                }
                while (byteCount > 0)
                {
                    if (byteCount < 1024)
                    {
                        break;
                    }
                    byteCount = stream.Read(recieve, 0, recieve.Length);
                }

            }
            FinalResult = FinalResult.Substring(0, FinalResult.IndexOf('}') + 1);
            return FinalResult;
        }
    }
}
public class ParseFromClient
{
    public string Requset { get; set; }
   
    bool isContains;
    public bool IsContains { get=>isContains; set { isContains = value; } }
    string name;
    public string Name { get => name; set => name = value; }
    string password;
    public string Password { get => password; set => password = value; }
}


