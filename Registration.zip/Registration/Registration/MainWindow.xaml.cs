﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Net;
using System.Net.Sockets;
using System.Text.Json;
using Registration;
namespace Registration
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    
    public partial class MainWindow : Window
    {
        static TcpClient client;
        static string UserName;
        static string USerPassword;
        static TextBlock ButtonLogOut=new TextBlock();
        static TextBlock ButtonPassword=new TextBlock();
        public MainWindow()
        {
            InitializeComponent();
            ButtonLogOut.Text= "Log out";
            ButtonPassword.Text = "Change Password";

        }
        
        private async void Button_Click_Register(object sender, RoutedEventArgs e)
        {
            Button button = sender as Button;
            string ButtonContext = button.DataContext as string;
            if (ButtonContext == null)
            {
                return;
            }
            client = new TcpClient();
            client.Connect(Dns.GetHostEntry(Dns.GetHostName()).AddressList[0], 8888);
            IsConnected();
            string RegName="";
            string RegPassword = "";
            string Command="";
            string StrError="";
            if (ButtonContext == "IsRegister")
            {
                if (RPassword.Text.Trim() == "" || RLogin.Text.Trim() == "")
                {
                    MessageBox.Show("Поля обязательны для заполнения");
                    return;
                }
                if (RPassword.Text != RRepeatPassword.Text)
                {
                    MessageBox.Show("Пароли не совпадают");
                    return;
                }
                RegName = RLogin.Text;
                RegPassword = RPassword.Text;
                Command = "AddUser";
                StrError = "Пользователь с таким именем уже существет";
            }
            if (ButtonContext == "IsLogIn")
            {
                if (LogInLogin.Text.Trim() == "" || LogInPassword.Text.Trim() == "")
                {
                    MessageBox.Show("Поля обязательны для заполнения");
                    return;
                }
                RegName = LogInLogin.Text;
                RegPassword = LogInPassword.Text;
                Command = "LogInUser";
                StrError = "Такого пользователь нет";
            }
            if(ButtonContext == "IsChangePassword")
            {
                if (ChnewPassword.Text.Trim() == "")
                {
                    MessageBox.Show("Поля обязательны для заполнения");
                    return;
                }
                if (ChnewPassword.Text != ChNewRepeatPassword.Text)
                {
                    MessageBox.Show("Пароли не совпадают");
                    return;
                }
                RegName = UserName;
                RegPassword = ChnewPassword.Text;
                Command = "ChangePassword";
                StrError = "Не удалось поменять пароль";
            }
            ParseFromClient parseFromClient = new ParseFromClient()
            {
                Requset = Command,
                Name = RegName,
                Password = RegPassword,
                CommandExecute = false
               
            };
            WriteStream(parseFromClient);
            while (true)
            {
                 var a=Task.Run(()=> parseFromClient = JsonSerializer.Deserialize<ParseFromClient>(StreamRead(client.GetStream())));
                 await a;
                 if (parseFromClient.Requset == "IsAnswer") 
                    break;
            }
            if (parseFromClient.CommandExecute)
            {
                if (ButtonContext != "IsChangePassword")
                {
                    ComboboxReg.Items.Remove(ButtonLogIn);
                    ComboboxReg.Items.Remove(ButtonReg);
                    ComboboxReg.Items.Add(ButtonLogOut);
                    ComboboxReg.Items.Add(ButtonPassword);
                }
                ComboboxReg.SelectedItem = ButtonPassword;
                UserName = parseFromClient.Name;
                USerPassword = parseFromClient.Password;
                Login.Text = "Name:" + UserName;
                if(ButtonContext== "IsChangePassword")
                {
                    MessageBox.Show("Пароль успешно изменён");
                    ChnewPassword.Text = "";
                    ChNewRepeatPassword.Text = "";
                }
            }
            else
            {
                MessageBox.Show(StrError);
            }
            client.Close();
        }
        static void WriteStream(ParseFromClient parseFromClient)
        {
            NetworkStream stream = client.GetStream();
            byte[] data = Encoding.UTF8.GetBytes(JsonSerializer.Serialize<ParseFromClient>(parseFromClient));
            stream.Write(data, 0, data.Length);
            
        }
        public void IsConnected()
        {
            if (client.Connected == false)
            {
                MessageBox.Show("Не удалось подключиться к серверу");
                Close();
            }
        }
        static string StreamRead(NetworkStream stream)
        {
            string FinalResult = "";
            while (true)
            {

                byte[] recieve = new byte[1024];
                var byteCount = stream.Read(recieve, 0, recieve.Length);
                if (byteCount < 1024)
                {
                    FinalResult += Encoding.UTF8.GetString(recieve, 0, byteCount);

                    break;
                }
                while (byteCount > 0)
                {
                    if (byteCount < 1024)
                    {
                        break;
                    }
                    byteCount = stream.Read(recieve, 0, recieve.Length);
                }

            }
            FinalResult = FinalResult.Substring(0, FinalResult.IndexOf('}') + 1);
            return FinalResult;
        }
        private void ButtonPassword_Click()
        {
            Register.Visibility = Visibility.Collapsed;
            LogIn.Visibility = Visibility.Collapsed;
            ChangedPassword.Visibility = Visibility.Visible;
        }

        private void ComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            TextBlock textBlock =ComboboxReg.SelectedItem as TextBlock;
            if (textBlock == null)
            {
                return;
            }
            if (textBlock.Text == "Register")
            {
                if (Register != null)
                {
                    Register.Visibility = Visibility.Visible;
                    LogIn.Visibility = Visibility.Collapsed;
                    ChangedPassword.Visibility = Visibility.Collapsed;
                }
            }
            if(textBlock.Text== "Log in")
            {
                Register.Visibility = Visibility.Collapsed;
                LogIn.Visibility = Visibility.Visible;
                ChangedPassword.Visibility = Visibility.Collapsed;
            }
            if(textBlock.Text== "Change Password")
            {
                ButtonPassword_Click();
            }
            if (textBlock.Text== "Log out")
            {
                ComboboxReg.Items.Remove(ButtonPassword);
                ComboboxReg.Items.Remove(ButtonLogOut);
                ComboboxReg.Items.Add(ButtonLogIn);
                ComboboxReg.Items.Add(ButtonReg);
                
                UserName = "";
                USerPassword = "";
                Login.Text = "";
                ComboboxReg.SelectedItem = ButtonReg;
            }
        }
    }
}
public class ParseFromClient
{
    public string Requset { get; set; }
   
    bool commandExecute;
    public bool CommandExecute { get=>commandExecute; set { commandExecute = value; } }
    string name;
    public string Name { get => name; set => name = value; }
    string password;
    public string Password { get => password; set => password = value; }
}


