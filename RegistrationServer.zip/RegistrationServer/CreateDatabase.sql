﻿
Create DATABASE Register;
use Register;
CREATE TABLE Users(
id int Primary KEY IDENTITY(1,1),
[Name] varchar(max),
[Password] varchar(max)
)