﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using System.Net.Sockets;
using System.Text.Json;
using System.Data.SqlClient;
using Dapper;
namespace RegistrationServer
{
    public class Program
    {
        static string StrConection = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=Register;Integrated Security=True;Connect Timeout=30;";
        static TcpListener serverMe = new TcpListener(IPAddress.Any, 8888);
        static void Main(string[] args)
        {
            serverMe.Start();
            var a = Task.Run(() => ListenFordata());
            a.Wait();
        }
        static void ListenFordata()
        {
            while (true)
            {
                TcpClient client = serverMe.AcceptTcpClient();
                Task.Run(() => GetrequestAndSendAnswer(client));
            }
        }
        static void GetrequestAndSendAnswer(TcpClient tcpClient)
        {
            
            using (NetworkStream networkStream = tcpClient.GetStream())
            {
                var resultString = StreamRead(networkStream);
       
                var a = JsonSerializer.Deserialize<ParseFromClient>(resultString);
                if (a.Requset == "AddUser")
                {
                   
                    User user = new User() { Name = a.Name, Password = a.Password };
                    a.IsContains=! AddUser(user);
                    byte[] data = Encoding.UTF8.GetBytes(JsonSerializer.Serialize<ParseFromClient>(a));
                    networkStream.Write(data, 0, data.Length);
                }
                if(a.Requset== "ChangePassword")
                {
                    User user = new User() { Name = a.Name, Password = a.Password };
                    a.IsContains = ChangePassword(user);
                    byte[] data = Encoding.UTF8.GetBytes(JsonSerializer.Serialize<ParseFromClient>(a));
                    networkStream.Write(data, 0, data.Length);
                }
                
            }
        }
        static bool AddUser(User user )
        {
            using (SqlConnection sqlConnection = new SqlConnection(StrConection))
            {
                var a = sqlConnection.Query<User>($"Select * from Users ").FirstOrDefault(c=>c.Name==user.Name);
                if (a != null)
                {
                    return false;
                }

                sqlConnection.Execute($"Insert INTO Users([Name],[Password]) values('{user.Name}','{user.Password}')");
                
                return true;
            }
        }
        static bool ChangePassword(User user)
        {
            using (SqlConnection sqlConnection = new SqlConnection(StrConection))
            {
                var a = sqlConnection.Query<User>($"Select * from Users ").FirstOrDefault(c => c.Name == user.Name);
                if (a == null)
                {
                    return false;
                }
                sqlConnection.Execute($"UPDATE Users SET Password='{user.Password}' WHERE [Name]='{user.Name}'");
                return true;
            }
         
        }
        static string StreamRead(NetworkStream stream)
        {
            string FinalResult = "";
            while (true)
            {

                byte[] recieve = new byte[1024];
                var byteCount = stream.Read(recieve, 0, recieve.Length);
                if (byteCount < 1024)
                {
                    FinalResult += Encoding.UTF8.GetString(recieve, 0, byteCount);

                    break;
                }
                while (byteCount > 0)
                {
                    if (byteCount < 1024)
                    {
                        break;
                    }
                    byteCount = stream.Read(recieve, 0, recieve.Length);
                }

            }
            FinalResult = FinalResult.Substring(0, FinalResult.IndexOf('}')+1);
            return FinalResult;
        }

        public class User
        {
            public string Name;
            public string Password;
        }
        public class ParseFromClient
        {
            public string Requset { get; set; }

            bool isContains;
            public bool IsContains { get => isContains; set { isContains = value; } }
            string name;
            public string Name { get => name; set => name = value; }
            string password;
            public string Password { get => password; set => password = value; }
        }
    }
}
